<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STYVO BANK</title>
</head>
<body>
    <strong>STYVO BANK </strong>
    <em>Mon inscription</em><br><br>
    <form action="../controle/inscrit.php" method="POST">
        <input type="text" name="nom" id="nom"  placeholder="NOM" required autofocus ><br><br>
        <input type="text" name="prenom" id="prenom"  placeholder="Prenoms" required><br><br>
        <input type="tel" name="num" id="num" placeholder="Numéro" required>
        <br><br>
        <input type="text" name="mail" id="mail" placeholder="Adresse mail" required>
        <br><br>
        
<br><br>
        <em>Genre</em><br>
        <input type="radio" name="sexe" value="F" id="feminin" required> <label for="feminin"> <em> F</em></label>
        <input type="radio" name="sexe"  value="M" id="masculin" required> <label for="masculin"> <em> M</em> </label>
        <br><br>
        <em> Date de naissance</em><br>
        <label for="jour"> <em> Jour</em></label>
         <select name="jour" id="Jour" required> 
            <option value="01">1</option>
            <option value="02">2</option>
            <option value="03">3</option>
            <option value="04">4</option>
            <option value="05">5</option>
            <option value="06">6</option>
            <option value="07">7</option>
            <option value="08">8</option>
            <option value="09">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="18">17</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>
        </select> 
        <label for="mois"> <em> Mois</em></label>
         <select name="mois" id="mois" required> 
            <option value="01">Janvier</option>
            <option value="02">Février</option>
            <option value="03">Mars</option>
            <option value="04">Avril</option>
            <option value="05">Mai</option>
            <option value="06">Juin</option>
            <option value="07">Juillet</option>
            <option value="08">Août</option>
            <option value="09">Septembre</option>
            <option value="10">Octobre</option>
            <option value="11">Novembre</option>
            <option value="12">Decembre</option>
         </select>
         <label for="Annee"> <em> Année</em> </label>
         <select name="annee" id="Annee" required placeholder="Année"> 
            <option value="2022">2022</option>
            <option value="2021">2021</option>
            <option value="2020">2020</option>
            <option value="2019">2019</option>
            <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
            <option value="2015">2015</option>
            <option value="2014">2014</option>
            <option value="2013">2013</option>
            <option value="2012">2012</option>
            <option value="2011">2011</option>
            <option value="2010">2010</option>
            <option value="2009">2009</option>
            <option value="2008">2008</option>
            <option value="2007">2007</option>
            <option value="2006">2006</option>
            <option value="2005">2005</option>
            <option value="2004">2004</option>
            <option value="2003">2003</option>
            <option value="2002">2002</option>
            <option value="2001">2001</option>
            <option value="2000">2000</option>
            <option value="1999">1999</option>
            <option value="1998">1998</option>
            <option value="1997">1997</option>
            <option value="1996">1996</option>
            <option value="1995">1995</option>
            <option value="1994">1994</option>
            <option value="1993">1993</option>
            <option value="1992">1992</option>
            <option value="1991">1991</option>
            <option value="1990">1990</option>
            <option value="1989">1989</option>
            <option value="1988">1988</option>
            <option value="1987">1987</option>
            <option value="1986">1986</option>
            <option value="1985">1985</option>
            <option value="1984">1984</option>
            <option value="1983">1983</option>
            <option value="1982">1982</option>
            <option value="1981">1981</option>
            <option value="1980">1980</option>
            <option value="1979">1979</option>
            <option value="1978">1978</option>
            <option value="1977">1977</option>
            <option value="1976">1976</option>
            <option value="1975">1975</option>
            <option value="1974">1974</option>
            <option value="1973">1973</option>
            <option value="1972">1972</option>
            <option value="1971">1971</option>
            <option value="1970">1970</option>
            <option value="1969">1969</option>
            <option value="1968">1968</option>
            <option value="1967">1967</option>
            <option value="1966">1966</option>
            <option value="1965">1965</option>
            <option value="1964">1964</option>
            <option value="1963">1963</option>
            <option value="1992">1962</option>
            <option value="1991">1961</option>
            <option value="1990">1960</option>
            <option value="1989">1959</option>
            <option value="1988">1958</option>
            <option value="1987">1957</option>
            <option value="1986">1956</option>
            <option value="1985">1955</option>
            <option value="1984">1954</option>
            <option value="1983">1953</option>
            <option value="1982">1952</option>
            <option value="1981">1951</option>
            <option value="1980">1950</option>
            <option value="1979">1949</option>
            <option value="1978">1948</option>
            <option value="1977">1947</option>
            <option value="1976">1946</option>
            <option value="1975">1945</option>
            <option value="1974">1944</option>
            <option value="1973">1943</option>
            <option value="1972">1942</option>
            <option value="1971">1941</option>
            <option value="1970">1940</option>
            <option value="1969">1939</option>
            <option value="1968">1938</option>
            <option value="1967">1937</option>
            <option value="1966">1936</option>
            <option value="1965">1935</option>
            <option value="1964">1934</option>
            <option value="1963">1933</option>
            <option value="1992">1932</option>
            <option value="1991">1931</option>
            <option value="1990">1930</option>
            <option value="1989">1929</option>
            <option value="1988">1928</option>
            <option value="1987">1927</option>
            <option value="1986">1926</option>
            <option value="1985">1925</option>
            <option value="1984">1924</option>
            <option value="1983">1923</option>
            <option value="1982">1922</option>
            <option value="1981">1921</option>
            <option value="1980">1920</option>
            <option value="1979">1919</option>
            <option value="1978">1918</option>
            <option value="1977">1917</option>
            <option value="1976">1916</option>
            <option value="1975">1915</option>
            <option value="1974">1914</option>
            <option value="1973">1913</option>
            <option value="1972">1912</option>
            <option value="1971">1911</option>
            <option value="1970">1910</option>
            <option value="1969">1909</option>
            <option value="1968">1908</option>
            <option value="1967">1907</option>
            <option value="1966">1906</option>
            <option value="1965">1905</option>
        </select> <br><br>
        <input type="submit" value="Suivant">
        </form>
</body>
</html>