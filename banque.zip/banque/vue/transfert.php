<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification</title>
</head>
<body>
    <php
    foreach($donnes as $donnes)
    {
        ?>
        Vous voulez envoyer <?php echo $sum.' XOF';?> à <br/><br/>
       <strong>
            <img src="<?php echo $donnes['ProfileUse'] ;?>" alt="photos">
            <strong><?php
            if($donnes['SexUse']=='M') 
            {
                echo "Mr " .strtoupper($donnes['nomUse'])." " . $donnes['PreUse'];
            }else
            {
               echo "Mme " .$donnes['nomUse']." " . $donnes['PreUse']; 
            }
            ?>
            <br/>
            Identifiant N° 0000<?php echo $donnes['idUse']?></strong><br><br>
        <em> Entrez votre mot de passe pour valider le transfert</em></strong><br><br>
            <form action="connexion.php?confir=1" method="POST">
                <input type="password" name="code" placeholder="Mot de passe" required autofocus><br><br>
                <input type="submit" value="Confirmer">

            </form>
            <?php
    ?>
</body>
</html>