<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STYVO BANK</title>
</head>
<body>
    <header>
        <strong> Styvo Bank </strong> la banque du futur <br>
        <em>Avec nous, votre argent ne <strike>risque</strike> rien</em><br><br>
        <?php foreach ($donnes as $key => $donne) {
            ?>
            <strong>N° bancaire : 0000<?php echo $donne['idUse']?></strong><br><br>
            <img src="<?php echo $donne['ProfileUse'] ;?>" alt="photos">
            <strong><?php
            if($donne['SexUse']=='M') 
            {
                echo "Mr " .strtoupper($donne['nomUse'])." " . $donne['PreUse'];
            }else
            {
               echo "Mme " .$donne['nomUse']." " . $donne['PreUse']; 
            }
            ?></strong>
            
        

    </header>
    <?php
    }
        ?><br><br><br>
    <nav>
        <ul>
            <li><a href="connexion.php?trans=1">Transfert d'argent</a> </li>
            <li>Retrait d'argent</li>
            <li><a href="transactions.php?facture=1">Mes transactions</a></li>
            <li><a href="connexion.php?solde=1">Mon solde</a> </li>
            <li>Services STYVO BANK</li>
        </ul>
    </nav><br><br>
    <p>
        Votre satisfaction, notre priorité.  
    </p>
</body>
</html>