<!DOCTYPE php>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- <link rel="stylesheet" href="design.css">-->
    <title>STYVO BANK</title>
</head>
<body class="form">
    <div class="styvo">
        <p>Styvo Bank : la banque du futur 💲💲</p>
    </div>
        <form action="controle/connexion.php" method="POST" class="res">
        <em> Connexion </em><br> <br>
        <label for="pseudo"> Mail</label><br/>
        <input type="text" name="mail" id="pseudo" autofocus required >
        <br><br>
        <label for="code"> Mot de passe </label><br/>
        <input type="password" name="code" id="code" required>
        <br><br>
        <input type="submit" value="Connexion" class="connexion">
        <br><br>
        </form>
        <a href="vue/inscription.php" class="creation">Créer un compte client</a>
        <br><br>
        <a href="controle/oublier.php" class="oublier">Mot de passe oublié ?</a>
    
    
</body>
</html>