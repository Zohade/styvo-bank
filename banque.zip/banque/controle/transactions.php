<?php
session_start();
//recupération des transactions de 
 $id=$_SESSION['id'];
 include_once('base.php');
 $req=$bdd->prepare('SELECT IdFac, SendFac, ReceFac,Somme,DateFac,(SELECT nomUse FROM users where 
 idUse=SendFac)AS nomSe,(SELECT PreUse FROM users WHERE idUse=SendFac)AS PreSe,
  (SELECT nomUse FROM users WHERE idUse=ReceFac) AS nomRec, 
  (SELECT PreUse FROM users WHERE idUse=ReceFac)AS PreRec 
  FROM factures INNER JOIN users ON factures.SendFac=users.idUse  
  WHERE (SendFac=? OR ReceFac=?) ORDER BY DateFac LIMIT 10');
  $req->execute(array($id,$id));
  $donnes=$req->fetchAll();
 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Transaction</title>
 </head>
 <body>
  <?php
    foreach($donnes as $key => $donne) { 
       

    if($id==$donne['ReceFac'])
    {
     ?>
     <p> Vous avez reçu un transfert de <?php echo $donne['Somme']?> de 
     <?php echo $donne['nomSe']." ".$donne['PreSe']." (0000000".$donne['SendFac'].") le ".$donne['DateFac'];?></p>
     <br><?php
    }elseif($id==$donne['SendFac']){
      
      ?><br><?php
    }
}
    ?>
 </body>
 </html>
