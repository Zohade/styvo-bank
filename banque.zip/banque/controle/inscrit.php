<?php
session_start();
if(isset($_POST['nom']) and isset($_POST['prenom']))
{
    if(isset($_POST['mail']) and isset($_POST['num']))
    {
        if(isset($_POST['annee']) and isset($_POST['mois']))
        {
            if(isset($_POST['jour']) and isset($_POST['sexe']))
            {
                $num=$_POST['num'];  
            //regex de vérification du numéro de téléphone, format bénin
            if(preg_match("#^[5-69]\d[-. ]?\d{2}[-. ]?\d{2}[-. ]?\d{2}$#","$num") xor
                                     preg_match("#^[4][0][-. ]?\d{2}[-. ]?\d{2}[-. ]?\d{2}$#","$num"))
          {                           
             $_SESSION['nom']=htmlspecialchars($_POST['nom']);
            $_SESSION['prenom']=htmlspecialchars($_POST['prenom']);
            $_SESSION['num']=$_POST['num'];                       
            $_SESSION['annee']=$_POST['annee'];
            $_SESSION['mois']=$_POST['mois'];
            $_SESSION['jour']=$_POST['jour'];
            $_SESSION['sexe']=$_POST['sexe'];
            $mail=htmlspecialchars($_POST['mail']);
             if(filter_var($mail, FILTER_VALIDATE_EMAIL))
             {
                $_SESSION['mail']=$mail;
                $users=$_SESSION;
                ?>
             <form action="valide.php" method="POST">
              <input type="text" name="job" placeholder="Travail" required><br><br>
              <label for=""> celibataire<input type="radio" name="statut" value="celibataire" required></label>
              <label for=""> marié(e)<input type="radio" name="statut" value="marie" required></label>
              <label for=""> veuf/veuve<input type="radio" name="statut" value="veuf" required></label><br><br>
              <em>(Choissisez une question et repondez-y)</em><br>
              <select name="quest" id="" required>
                <option value="Quel est votre jour de la semaine préféré ?">Quel est votre jour de la semaine préféré ?</option>
                <option value="Quel est le nom de votre frère préféré ?">Quel est le nom de votre frère préféré ?</option>
                <option value="Quel est le nom de votre soeur préférée ?">Quel est le nom de votre soeur préférée ?</option>
                <option value="Quel était votre pseudo de jeunesse ?">Quel était votre pseudo de jeunesse ?</option>
              </select><br><br>
              <input type="text" name="rep" placeholder="reponse" required><br><br>
              <input type="password" name="code" placeholder="Mot de passe" required> <em> (06 caracteres)</em><br><br>
              <input type="submit" value="S'incrire">
             </form>
             <?php
             }
             else {
                echo 'Adresse mail invalide';
                ?><br><?php
                include_once('../vue/inscription.php');
             }
             
            } else {
                echo 'votre numéro est invlaide';
                }
            }
            }
        }
}
