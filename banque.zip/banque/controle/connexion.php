<?php
session_start();
if(isset($_POST['code']) and isset($_POST['mail']))
{//connexion à l'acceuil
    $mail=htmlspecialchars($_POST['mail']);
    $code=htmlspecialchars($_POST['code']);
    $code=hash('sha256',$code);
    include_once("base.php");
    global $bdd;
    $req=$bdd->prepare('SELECT * FROM users WHERE MailUse=?');
    $req->execute(array($mail));
    $donnes=$req->fetchAll();
    foreach ($donnes as $key => $donne) {
        if($donne['CodeUse']==$code)
        {
            $_SESSION['id']=$donne['idUse'];
            $_SESSION['code']=$code;
           include_once('../vue/connexion.php');
        }
    }


}
elseif (isset($_GET['solde'])) {//verifier son solde
  ?>
  <strong>Entrez votre mot de passe</strong><br>
  <form action="solde.php" method="POST">
    <input type="password" name="passolde" placeholder="Mot de passe" required autofocus>
    <input type="submit" value="Envoyer">
  </form>
  <?php 
}
elseif(isset($_GET['trans']))//formulaire pour envoyer de l'argent
{
  ?>
   <form action="connexion.php" method="POST">
   <label for="rec"> Numéro de compte du destinataire : </label>  
   <input type="number" name="rec" id="rec" required autofocus><br><br>
   <label for="sum">  Montant : </label>
   <input type="number" name="sum" required id="sum"><br><br>
   <input type="submit" value="Suivant">
   </form>
  <?php
}
//envoi d'argent
elseif (isset($_POST['rec']) and isset($_POST['sum'])) {
  $sum=htmlspecialchars($_POST['sum']);
  $rec=htmlspecialchars($_POST['rec']);
   $_SESSION['sum']=$sum;
  $_SESSION['rec']=$rec;
  $id=$_SESSION['id'];
  include_once('base.php');
  global $bdd;
  //selectionne le solde de l'utilisateur
  $req=$bdd->prepare('SELECT SoldeAcc FROM accounts WHERE UserAcc=?');
  $req->execute(array($id));
  $donne=$req->fetchAll();
  foreach ($donne as $cle => $donne) {
     if((0<$sum) and ($sum<$donne['SoldeAcc']))
     {// vérifier si son solde est suffisant pour effectuer la transaction
       $req1=$bdd->prepare('SELECT idUse, nomUse, PreUse, SexUse, ProfileUse  FROM  users  WHERE idUse=?');
       $req1->execute(array($rec));
       $donnes=$req1->fetchAll();
       if($donnes)
       {//vérifier l'existence de l'utilisateur
       $_SESSION['solde']=$donne['SoldeAcc']; 
        foreach ($donnes as $cle => $donnes) {
          include_once('../vue/transfert.php');
        }
         
        }else
       {
        echo "Le numéro bancaire du receveur n'existe pas";
       }
      }
     else {//si solde insuffisant
      echo 'Votre solde est insuffisant pour effectuer cette transactoin';
     }
}
}
elseif (isset($_GET['confir']) and isset($_POST['code'])) {
 $code=hash('sha256', htmlspecialchars($_POST['code']));
 if($code==$_SESSION['code'])
 {
  $sum=$_SESSION['sum'];//somme envoyée 
  $rec=$_SESSION['rec'];//receveur id
  $id=$_SESSION['id'];//envoyeur id
  //transaction des fonds
  include_once('base.php');// connexion base banque;
  try {
    global $bdd;
    //debute une transaction pour eviter perte de données 
    $req=$bdd->query('start transaction');
    //soustraction des sous du compte de l'envoyeur
    $req1=$bdd->prepare('UPDATE accounts SET SoldeAcc=SoldeAcc-? WHERE UserAcc=?');
    $feedback=$req1->execute(array($sum,$id));
    if($feedback){
      //ajout au compte receveur
      $req2=$bdd->prepare('UPDATE accounts SET SoldeAcc=SoldeAcc+? WHERE UserAcc=?');
    $feedback1=$req2->execute(array($sum,$rec));
    if($feedback1){
      //enregistre la facture 
      $req3=$bdd->prepare('insert into factures (SendFac, ReceFac, Somme) values (?,?,?)');
    $feedback2=$req3->execute(array($id,$rec,$sum));
        if($feedback2){
          $req4=$bdd->query('COMMIT');
          echo "Votre transaction a réussi. Votre solde actuel est : ". ($_SESSION['solde']-$_SESSION['sum'])." XOF";
        }else{//affiche une erreur si l'enregistrement de la facture n'a pas abouti
          $req4=$bdd->query('ROLLBACK');
          echo "Une erreur s'est produite et la transaction a été interrompu";
        }
    }else{//break!!! l'ajout au compte receveur n'a pas abouti
      $req4=$bdd->query('ROLLBACK');
      echo "Une erreur s'est produite et la transaction a été interrompu";
    }
    }else{//break, la requete de soustraction du compte envoyeur n'a pas abouti
      $req4=$bdd->query('ROLLBACK');
      echo "Une erreur s'est produite et la transaction a été interrompu";
    }  
  } catch (Exception $th) {
    die("Transaction non effectué");
  }
 }else{
  echo ' Mot de passe incorrect';
 }
}
