<?php
//création du client avec ses infos 
session_start();
if(isset($_POST['job']) and isset($_POST['statut']) and isset($_POST['code']))
{
    if(isset($_POST['quest']) and isset($_POST['rep']))
    { 
    if(strlen($_POST['code'])==6)
    {
     $quiz=nl2br(htmlspecialchars($_POST['quest']));
     $rep=nl2br(htmlspecialchars($_POST['rep']));
     $job=nl2br(htmlspecialchars($_POST['job']));
     $statut=htmlspecialchars($_POST['statut']);
     $code=htmlspecialchars($_POST['code']); 
     $code=hash('sha256', $code);
           $nom=$_SESSION['nom'];
           $prenom=$_SESSION['prenom'];
           $num=$_SESSION['num'];
            $annee=$_SESSION['annee'];
            $mois=$_SESSION['mois'];
            $jour=$_SESSION['jour'];
            $sexe=$_SESSION['sexe'];
            $mail=$_SESSION['mail'];
            $date=$annee.'-'.$mois.'-'.$jour;
            include_once("base.php");
           global $bdd;
           $req=$bdd->prepare('INSERT INTO users (nomUse, MailUse, NumUse, BirthUse
           , JobUse, ProfileUse, PreUse, SexUse, StatutUse, quest, rep, CodeUse)
           VALUES (?,?,?,?,?,"../profile/profilenulle.jpg",?,?,?,?,?,?)');
           $feedback=$req->execute(array($nom,$mail, $num, $date, $job, 
        $prenom, $sexe, $statut, $quiz, $rep,$code));
        //$req->close_cursor();
       if($feedback==1)
       {
        $req1=$bdd->prepare('INSERT INTO accounts (SELECT NULL, idUse, 0 FROM
         users WHERE MailUse=?)');
        $retour=$req1->execute(array($mail));
        if($retour==1)
        {
          echo "Felicitation,vous venez d'integrer la grande famille des clients de Styvo Bank.";
        }
      }  
       }
            
    }
    else{
        echo 'Le mot de passe doit etre de 6 caracteres';
    }
session_destroy();
    }        

