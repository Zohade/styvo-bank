<?php
session_start();
if(isset($_POST['mail']) and isset($_POST['num']))
{
    if (isset($_POST['nom']) and isset($_POST['prenom'])) {
        $mail=htmlspecialchars($_POST['mail']);
        $num=htmlspecialchars($_POST['num']);
        if(filter_var($mail, FILTER_VALIDATE_EMAIL) and (preg_match("#^[5-69]\d[-. ]?\d{2}[-. ]?\d{2}[-. ]?\d{2}$#","$num") xor
                                     preg_match("#^[4][0][-. ]?\d{2}[-. ]?\d{2}[-. ]?\d{2}$#","$num")))
        {
        $_SESSION['mail']=$mail;  
        $_SESSION['nom']=htmlspecialchars($_POST['nom']);
        $_SESSION['num']=$num;
        $_SESSION['prenom']=htmlspecialchars($_POST['prenom']);
  include_once('base.php');
  global $bdd;
  $req=$bdd->prepare('SELECT * FROM users WHERE MailUse=?'); 
  $req->execute(array($_SESSION['mail']));
  $donnes=$req->fetchAll();
  foreach ($donnes as $cle => $donne) {
     if($donne['nomUse']==$_SESSION['nom'] and $donne['NumUse']==$_SESSION['num']
     and $donne['PreUse']==$_SESSION['prenom'])
     {
        $_SESSION['id']=$donne['idUse'];
        $_SESSION['rep']=$donne['rep'];
       ?>
       <!DOCTYPE html>
       <html lang="en">
       <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>reponse aux questions</title>
       </head>
       <body>
        <em>Répondez à la question que vous aviez choisi</em>
        <form action="#" method="POST">
         <strong><?php echo $donne['quest']." :   ";?></strong>
         <input type="text" name="rep" placeholder="Votre reponse" required autofocus>
         <input type="submit" value="Suivant">
        </form>
       </body>
       </html>
       <?php
     }
  }
        }
 }
}
elseif(isset($_POST['rep'])) {
$rep=nl2br(htmlspecialchars($_POST['rep']));
if($rep==$_SESSION['rep'])
{
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nouveau mot de passe  </title>
    </head>
    <body>
      <form action="#" method="POST">
        <input type="password" name="code" placeholder="Nouveau code" required autofocus>  <em>06 caracteres</em><br><br>
        <input type="password" name="concode" placeholder="Confirmer" required >  <em>06 caracteres</em><br></br>
        <input type="submit" value="Changer">
      </form>  
    </body>
    </html>
    <?php
}

}
elseif (isset($_POST['code']) and isset($_POST['concode']) ) {
    if(strlen($_POST['code'])==06)
    {  
    $code=htmlspecialchars($_POST['code']);
    $concode=htmlspecialchars($_POST['concode']);
    if($code==$concode)
    {
        $id=$_SESSION['id'];
       $code=hash('sha256',$code);
       include_once('base.php');
       global $bdd;
       $req=$bdd->prepare('UPDATE users SET CodeUse=? WHERE idUse=?');
      $retour=$req->execute(array($code, $id));
      if($retour==1)
      {
        echo ' Changement bien effectué. ';
        ?><a href="../index.php">Connectez vous </a>
        <?php
      }
    }
    else {
        echo 'Confirmer avec le meme code';
    }
    
    }else
    {
      echo 'le mot de passe doit contenir exactement 6 carateres';
    }

}
else {
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié</title>
</head>
<body>
    <p>
        Veillez remplir les champs suivants pour réinitialiser votre mot de passe
    </p>
    <form action="#" method="POST">
        <input type="text" name="nom" placeholder="Votre nom" required autofocus><br><br>
        <input type="text" name="prenom" placeholder="Votre prenom" required autofocus><br><br>
        <input type="text" name="mail" placeholder="Votre mail" required autofocus><br><br>
        <input type="number" name="num" placeholder="Votre numéro" required><br><br>
        <input type="submit" value="Suivant">
    </form>
    
</body>
</html>
<?php
}