<?php
session_start();
if(isset($_POST['passolde']))
{
   $code=htmlspecialchars($_POST['passolde']);
   $code=hash('sha256', $code);
   if($_SESSION['code']==$code)
   {
    include_once('base.php');
    global $bdd;
    $req=$bdd->prepare('SELECT SoldeAcc FROM accounts WHERE UserAcc=?');
    $req->execute(array($_SESSION['id']));
    $donne=$req->fetchAll();
    foreach ($donne as $cle => $donne) {
      echo 'Votre solde actuel est de '. $donne['SoldeAcc'].' XOF';
    }
   }
}